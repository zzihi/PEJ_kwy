package mybnb;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface AlarmRepository extends PagingAndSortingRepository<Alarm, Long>{


}