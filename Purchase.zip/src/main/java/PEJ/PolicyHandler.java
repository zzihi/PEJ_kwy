package PEJ;

import PEJ.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{

    @Autowired
    PurchaseRepository purchaseRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOutOfStock_Cancel(@Payload OutOfStock outOfStock){

        if(outOfStock.isMe()){
            Purchase purchase = new Purchase();

            purchase.setPurchaseId(outOfStock.getPurchaseId());

            purchaseRepository.delete(purchase);

        }

    }

}
